"use strict";
var User = (function () {
    function User(id, email, name, password) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.password = password;
    }
    return User;
}());
exports.User = User;
//# sourceMappingURL=user.js.map