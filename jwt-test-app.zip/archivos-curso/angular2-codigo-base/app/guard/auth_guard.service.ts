import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CanActivate, CanActivateChild } from '@angular/router';
import { Auth } from '../providers/auth/auth.service';

@Injectable()
export class AuthGuard 
{

}