import { BaseResponseOptions, Request, Response, XHRBackend, XHRConnection } from '@angular/http';
import { Observable } from 'rxjs/Rx';

export class InterceptorXHRBackend extends XHRBackend 
{

}