import { OnInit, Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../classes/user';
import { Auth } from '../../providers/auth/auth.service';
import {JwtHelper} from 'angular2-jwt';

@Component({
  moduleId: module.id,
  selector: 'app-login',
  templateUrl: 'login.html',
  styleUrls: ['login.css']
})

export class LoginComponent
{
  
}
