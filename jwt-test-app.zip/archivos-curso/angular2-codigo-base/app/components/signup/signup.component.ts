import { Auth } from '../../providers/auth/auth.service';
import { OnInit, Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../classes/user';


@Component({
  moduleId: module.id,
  selector: 'signup',
  templateUrl: 'signup.html',
  styleUrls: ['../login/login.css']
})
export class SignupComponent
{

}
